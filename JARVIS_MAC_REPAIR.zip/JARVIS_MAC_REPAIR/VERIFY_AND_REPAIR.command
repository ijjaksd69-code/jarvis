#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'Run this on your Mac with your existing JARVIS installation.'
  exit 2
fi
/usr/bin/python3 verify_and_repair_mac.py
result=$?
read -r -p 'Press Enter to close...' _answer
exit "$result"
