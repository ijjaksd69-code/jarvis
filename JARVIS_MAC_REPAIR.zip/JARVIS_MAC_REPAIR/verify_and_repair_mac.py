"""Apply reviewed repairs and guide real Mac tests without replacing user assets."""
import json,os,plistlib,subprocess,sys,time
from pathlib import Path
from apply_repairs import apply
HERE=Path(__file__).resolve().parent
ROOT=Path.home()/'Library/Application Support/JARVIS Always On'
LABEL='local.jarvis.alwayson'

def capture(command,timeout=60):
    proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try: out,err=proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try: proc.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.communicate()
        raise RuntimeError('Check timed out: '+Path(command[0]).name) from None
    if proc.returncode:
        raise RuntimeError((err or out or 'Command failed').strip()[-600:])
    return out.strip()

def interpreter():
    plist=Path.home()/'Library/LaunchAgents'/f'{LABEL}.plist'
    config=plistlib.loads(plist.read_bytes()); args=config.get('ProgramArguments')
    if config.get('Label')!=LABEL or not isinstance(args,list) or not all(isinstance(x,str) for x in args):
        raise RuntimeError('Unexpected existing LaunchAgent.')
    if len(args)==3 and args[1]=='-u': script=args[2]
    elif len(args)==2: script=args[1]
    else: raise RuntimeError('Unsupported LaunchAgent argument layout.')
    if Path(script) not in [ROOT/'jarvis_wake_controller.py',ROOT/'always_on.py']:
        raise RuntimeError('Unknown startup script; existing configuration left unchanged.')
    python=Path(args[0])
    if not python.is_file() or not os.access(python,os.X_OK):
        raise RuntimeError('Existing JARVIS Python runtime is missing. Keep this installation intact; runtime setup is needed.')
    return str(python)

def restart():
    # Original service-repair flow: enable, bootstrap if unloaded, kickstart.
    # Discard its old log tails here; the shareable report contains no chats.
    result=subprocess.run(['/bin/bash',str(HERE/'START_JARVIS_LISTENER.command')],
                          input='\n',capture_output=True,text=True,timeout=60)
    return result.returncode==0

def main():
    if sys.platform!='darwin':
        print('This final verification must run on your Mac, beside your existing JARVIS installation.')
        return 2
    results={}; paused=False
    try:
        python=interpreter()
        capture([python,'-c','import torch, tkinter'],timeout=60)
        apply(ROOT,check_only=True)
        capture([python,str(ROOT/'model_health.py')],timeout=180)
        results['active_model_load']='passed'
        service=f'gui/{os.getuid()}/{LABEL}'
        # Stop the service before replacing source or acquiring the microphone.
        current=subprocess.run(['/bin/launchctl','print',service],capture_output=True,text=True)
        if current.returncode==0:
            capture(['/bin/launchctl','bootout',service],timeout=30)
        paused=True
        if subprocess.run(['/bin/launchctl','print',service],capture_output=True).returncode==0:
            raise RuntimeError('Service is still registered; stop before microphone tests.')
        results['repaired_source_files']=apply(ROOT)
        print('Repairs applied. Models, memory, voice preferences and hologram assets preserved.')
        value=capture([python,str(ROOT/'voice_bridge.py'),'--check'],timeout=40)
        if value!='PERMISSION_OK': raise RuntimeError('Permission check did not return PERMISSION_OK.')
        results['permissions']='passed'
        print('Pause music/video. Say Hey Jarvis now; listening for up to 30 seconds.',flush=True)
        value=capture([python,str(ROOT/'voice_bridge.py'),'--wake','--max-wait','30'],timeout=45)
        if value!='WAKE': raise RuntimeError('Wake check did not return WAKE.')
        results['real_wake_phrase']='passed'
        print('Speaker test: listen for two numbered sentences.',flush=True)
        output=capture([python,str(HERE/'check_voice_on_mac.py')],timeout=250)
        print(output)
        results['voice_worker']='completed'
        results['both_sentences_audible']=input('Did you hear BOTH sentences clearly? [y/N] ').strip().lower()=='y'
        results['voice_delay_acceptable']=input('Did both sentences begin without an excessive delay? [y/N] ').strip().lower()=='y'
    except (Exception,KeyboardInterrupt) as exc:
        print('CHECK STOPPED:',str(exc))
        results['checks_completed']=False
        results['failure_type']=type(exc).__name__
    finally:
        if paused:
            try: results['service_running']=restart()
            except Exception as exc:
                results['service_running']=False
                print('Service restart needs attention:',type(exc).__name__)
        if results.get('service_running') and results.get('real_wake_phrase')=='passed':
            try:
                print('Now say Hey Jarvis, try an ordinary command, say go to sleep, and wake it again.')
                results['live_hologram_commands_sleep_rewake']=input('Did ALL these steps work? [y/N] ').strip().lower()=='y'
            except (EOFError,KeyboardInterrupt): results['live_hologram_commands_sleep_rewake']=False
        results['ready_confirmed']=all([
            results.get('active_model_load')=='passed',results.get('permissions')=='passed',
            results.get('real_wake_phrase')=='passed',results.get('voice_worker')=='completed',
            results.get('both_sentences_audible') is True,results.get('voice_delay_acceptable') is True,
            results.get('service_running') is True,results.get('live_hologram_commands_sleep_rewake') is True])
        report=Path.home()/'Desktop/JARVIS_VERIFICATION_RESULT.json'
        try: report.write_text(json.dumps(results,indent=2)+'\n'); print('Results:',report)
        except OSError: print(json.dumps(results,indent=2))
    print('MAC CHECKS PASSED.' if results['ready_confirmed'] else 'NOT YET VERIFIED READY. Keep the result report for the next repair step.')
    return 0 if results['ready_confirmed'] else 1

if __name__=='__main__': raise SystemExit(main())
