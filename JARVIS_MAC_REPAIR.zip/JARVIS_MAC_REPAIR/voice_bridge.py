"""LaunchServices-based IPC for JARVIS's macOS microphone helper.

Important: macOS TCC may assign privacy permissions differently to an app
launched with LaunchServices and to the bare executable inside its bundle.
All microphone sessions therefore open the actual JARVIS Mic.app and exchange
only short status messages via an isolated per-session temporary directory.
"""
from __future__ import annotations

import os
import signal
import subprocess
import tempfile
import time
from pathlib import Path

APP = Path(__file__).resolve().parent / 'voice' / 'JARVIS Mic.app'


class SpeechLaunchError(RuntimeError):
    pass


class SpeechSession:
    def __init__(self, app=APP, *, opener=None, clock=time.monotonic, sleeper=time.sleep):
        self.app = Path(app)
        self.opener = opener or subprocess.run
        self.clock = clock
        self.sleeper = sleeper
        self.temp = None
        self.status = None
        self.pid = None
        self.cancelled = False

    def run(self, mode, *, timeout=45, cancellation=None):
        if mode not in ('wake', 'listen', 'check'):
            raise ValueError('Invalid microphone session mode')
        if not (self.app / 'Contents' / 'Info.plist').is_file():
            raise SpeechLaunchError('JARVIS Mic.app is missing. Run the voice installer first.')
        self.temp = tempfile.TemporaryDirectory(prefix='jarvis-speech-')
        self.status = Path(self.temp.name) / 'result.txt'
        arguments = {'wake': ['--wake'], 'listen': [], 'check': ['--check-permissions']}[mode]
        cmd = ['/usr/bin/open', '-n', '-a', str(self.app), '--args', *arguments,
               '--status-file', str(self.status)]
        try:
            result = self.opener(cmd, capture_output=True, text=True, timeout=12, check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            self.close()
            raise SpeechLaunchError('macOS could not launch the JARVIS Mic app: ' + str(exc)) from exc
        if result.returncode != 0:
            self.close()
            raise SpeechLaunchError('macOS could not open JARVIS Mic.app: ' +
                                    ((result.stderr or result.stdout or '').strip() or f'exit {result.returncode}'))
        start = self.clock()
        while timeout is None or self.clock() - start < timeout:
            if self.cancelled or (cancellation is not None and not cancellation()):
                self.close()
                return None
            if self.status.exists():
                try:
                    content = self.status.read_text(encoding='utf-8').strip()
                except (FileNotFoundError, PermissionError, UnicodeError):
                    content = ''
                if content.startswith('START\t'):
                    try:
                        self.pid = int(content.split('\t', 1)[1])
                    except (ValueError, IndexError):
                        pass
                elif content.startswith('ERROR\t'):
                    self.close()
                    raise SpeechLaunchError(content.split('\t', 1)[1][:500])
                elif content == 'WAKE' and mode == 'wake':
                    self.close()
                    return 'WAKE'
                elif content == 'PERMISSION_OK' and mode == 'check':
                    self.close()
                    return 'PERMISSION_OK'
                elif content.startswith('TEXT\t') and mode == 'listen':
                    value = content.split('\t', 1)[1].strip()
                    self.close()
                    return value
            # A wake session has no overall timeout, but the helper must start
            # and remain alive. Otherwise the controller never gets to retry.
            if self.pid is not None:
                try:
                    os.kill(self.pid, 0)
                except ProcessLookupError:
                    self.close()
                    raise SpeechLaunchError('JARVIS microphone helper exited without a result.') from None
                except PermissionError:
                    pass  # Lack of signal permission does not prove it exited.
            elif self.clock() - start >= 15:
                self.close()
                raise SpeechLaunchError('JARVIS microphone helper returned no startup status.')
            self.sleeper(0.15)
        self.close()
        raise SpeechLaunchError('The JARVIS Mic app did not return a result. Check microphone and Speech Recognition permissions, and confirm that macOS can open JARVIS Mic.app.')

    def close(self):
        self.cancelled = True
        if self.pid is not None:
            # Only terminate the dedicated helper, never an arbitrary process.
            try:
                proc = subprocess.run(['/bin/ps', '-p', str(self.pid), '-o', 'comm='],
                                      capture_output=True, text=True, timeout=2, check=False)
                if proc.returncode == 0 and Path(proc.stdout.strip()).name == 'MacSpeechHelper':
                    os.kill(self.pid, signal.SIGTERM)
            except (OSError, subprocess.TimeoutExpired, ProcessLookupError, PermissionError):
                pass
        self.pid = None
        if self.temp is not None:
            self.temp.cleanup()
            self.temp = None


def main():
    import argparse
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--check', action='store_true')
    group.add_argument('--wake', action='store_true')
    group.add_argument('--listen', action='store_true')
    parser.add_argument('--max-wait', type=float, default=None, help='Optional wake-test timeout in seconds')
    args = parser.parse_args()
    mode = 'check' if args.check else 'wake' if args.wake else 'listen'
    import sys
    session = SpeechSession()
    def terminate(*_):
        session.close()
        raise SystemExit(143)
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    try:
        value = session.run(mode, timeout=args.max_wait if mode == 'wake' else 20)
    except SpeechLaunchError as exc:
        print('FAIL:', exc, file=sys.stderr)
        raise SystemExit(1)
    print(value, flush=True)


if __name__ == '__main__':
    main()
