"""Measure two actual app speech calls without changing voice preferences."""
import sys
import time
from pathlib import Path


def main():
    if sys.platform != 'darwin':
        raise SystemExit('Run this playback check on your Mac.')
    root = Path.home() / 'Library/Application Support/JARVIS Always On'
    sys.path.insert(0, str(root))
    import natural_voice_bridge
    import voice_input
    print('Configured mode:', voice_input._selected_speed_mode())
    print('Selected natural voice:', natural_voice_bridge.selected_voice())
    print('Listen for both sentences. Worker completion alone does not prove audible output.')
    for number in (1, 2):
        start = time.monotonic()
        job = voice_input.say(f'This is speech verification number {number}. Daniel is ready to assist you.')
        if job is None:
            raise RuntimeError('Speech call returned no playback job.')
        code = job.wait(timeout=120)
        if code != 0:
            raise RuntimeError(f'Playback exited with status {code}')
        print(f'Round {number}: worker completed in {time.monotonic()-start:.2f}s, including playback.')
    print('Record whether both sentences were audible, and roughly when each began.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
