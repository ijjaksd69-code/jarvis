#!/bin/bash
# Restore only the existing JARVIS per-user login service. No models are modified.
set -u
LABEL='local.jarvis.alwayson'
APP_ROOT="$HOME/Library/Application Support/JARVIS Always On"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
LAUNCHCTL='/bin/launchctl'
UID_VALUE="$(/usr/bin/id -u)"
SERVICE="gui/$UID_VALUE/$LABEL"
DOMAIN="gui/$UID_VALUE"

finish() {
  local result="$1"
  printf '\n'
  read -r -p 'Press Enter to close this window...' _answer
  exit "$result"
}

echo '=== JARVIS BACKGROUND LISTENER SERVICE REPAIR ==='
echo 'Only re-enables/starts your existing service. No AI weights, memory, voices, or source files are modified.'
echo ''
if [[ "$(/usr/bin/uname -s)" != 'Darwin' ]]; then
  echo 'ERROR: This must run on your Mac.'
  finish 2
fi
if [[ ! -x "$LAUNCHCTL" ]]; then
  echo 'ERROR: macOS /bin/launchctl is unavailable.'
  finish 2
fi
if [[ ! -f "$PLIST" || -L "$PLIST" ]]; then
  echo "ERROR: Missing or unsafe service configuration: $PLIST"
  echo 'Do NOT run the full old installer; share this message and your installer output.'
  finish 2
fi

# Verify existing paths without creating a new agent or guessing program names.
if ! /usr/bin/python3 - "$PLIST" "$APP_ROOT" <<'PREFLIGHT'
import os, plistlib, sys
from pathlib import Path
plist_path, root_arg = sys.argv[1:]
root = Path(root_arg)
try:
    config = plistlib.loads(Path(plist_path).read_bytes())
    args = config['ProgramArguments']
    if config.get('Label') != 'local.jarvis.alwayson':
        raise ValueError('Unexpected service label')
    if not isinstance(args, list) or len(args) < 2:
        raise ValueError('Service ProgramArguments missing')
    # Python's -u is an interpreter option, not the entrypoint. Accept only
    # the two known layouts; never skip arbitrary options such as -c or -m.
    if not all(isinstance(arg, str) for arg in args):
        raise ValueError('Service arguments must be strings')
    if len(args) == 3 and args[1] == '-u':
        program, script = Path(args[0]), Path(args[2])
    elif len(args) == 2:
        program, script = map(Path, args)
    else:
        raise ValueError('Unsupported startup arguments. Nothing changed')
    if not program.is_file() or not os.access(program, os.X_OK):
        raise ValueError('Startup Python executable not found: ' + str(program))
    if script not in (root / 'jarvis_wake_controller.py', root / 'always_on.py'):
        raise ValueError('Unknown startup script. Nothing changed: ' + str(script))
    if not script.is_file():
        raise ValueError('Startup script is missing: ' + str(script))
    if not (root / 'voice_bridge.py').is_file():
        raise ValueError('voice_bridge.py missing; wake would not work')
    print('PASS: existing login service configuration is valid')
    print('Startup Python:', program)
    print('Startup script:', script.name)
except (OSError, KeyError, TypeError, ValueError) as exc:
    print('PREFLIGHT FAILED:', exc)
    sys.exit(1)
PREFLIGHT
then
  echo 'No changes made.'
  finish 2
fi

# An agent can be intentionally paused with bootout; bootstrap restores it.
echo ''
echo 'Enabling login service...'
if ! "$LAUNCHCTL" enable "$SERVICE"; then
  echo 'WARNING: enable returned an error. Attempting to load existing service anyway.'
fi
if ! "$LAUNCHCTL" print "$SERVICE" >/dev/null 2>&1; then
  echo 'Service was unloaded; bootstrapping into the graphical login session.'
  if ! "$LAUNCHCTL" bootstrap "$DOMAIN" "$PLIST"; then
    echo 'ERROR: macOS rejected the service bootstrap.'
    echo 'Your files were not modified. See the service/error logs below.'
    if [[ -f "$APP_ROOT/jarvis_errors.log" ]]; then /usr/bin/tail -n 12 "$APP_ROOT/jarvis_errors.log"; fi
    finish 1
  fi
else
  echo 'Service was already registered; checking/restarting it.'
fi

# kickstart is not sufficient on an UNLOADED agent; bootstrap above is required.
if ! "$LAUNCHCTL" kickstart -k "$SERVICE"; then
  echo 'WARNING: service kickstart returned an error. Checking its actual state.'
fi

WORKING=0
for _ in 1 2 3 4 5; do
  REPORT="$("$LAUNCHCTL" print "$SERVICE" 2>&1)"
  if [[ "$REPORT" == *'state = running'* && "$REPORT" == *'pid = '* ]]; then
    WORKING=1
    break
  fi
  /bin/sleep 1
done

echo ''
if [[ "$WORKING" -eq 1 ]]; then
  echo 'SUCCESS: JARVIS login service is loaded and its process is running.'
  echo 'Now pause Mac playback and say: Hey Jarvis'
  echo 'If the hologram does not appear, the remaining problem is wake recognition or the JARVIS process. See logs below.'
else
  echo 'ERROR: JARVIS is not confirmed running. This indicates a startup crash or a macOS service error.'
  echo 'Diagnostic status:'
  printf '%s\n' "$REPORT" | /usr/bin/grep -E 'state =|pid =|last exit code =|program =|path =' | /usr/bin/head -n 14 || true
fi

printf '\n=== Last 15 lines of JARVIS error log ===\n'
if [[ -f "$APP_ROOT/jarvis_errors.log" ]]; then
  /usr/bin/tail -n 15 "$APP_ROOT/jarvis_errors.log"
else
  echo '(No error log exists.)'
fi
printf '\n=== Last 10 lines of JARVIS service log ===\n'
if [[ -f "$APP_ROOT/jarvis_service.log" ]]; then
  /usr/bin/tail -n 10 "$APP_ROOT/jarvis_service.log"
else
  echo '(No service log exists.)'
fi
printf '\nNeural voice playback is independent of service startup. Run TEST_SPEAKING_VOICE.command to check it.\n'
if [[ "$WORKING" -eq 1 ]]; then finish 0; else finish 1; fi
