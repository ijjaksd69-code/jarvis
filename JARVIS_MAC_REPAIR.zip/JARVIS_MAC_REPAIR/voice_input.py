"""Opt-in, push-to-talk macOS speech transcription; no open-ended background listening."""
from __future__ import annotations
from pathlib import Path
import subprocess
import sys

MIC_BINARY = Path(__file__).resolve().parent / 'voice/JARVIS Mic.app/Contents/MacOS/MacSpeechHelper'


def listen(timeout=25, executable=MIC_BINARY):
    if sys.platform != 'darwin':
        raise RuntimeError('Microphone voice input currently supports macOS only.')
    if not Path(executable).is_file():
        raise RuntimeError('Microphone helper is not installed. Open Terminal in JARVIS Hologram and run: bash build_voice.sh')
    process = subprocess.Popen(
        [sys.executable, '-u', str(Path(__file__).resolve().parent / 'voice_bridge.py'), '--listen'],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        output, error = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        # SIGTERM lets the bridge close its dedicated native microphone helper.
        # subprocess.run(timeout=...) instead kills the bridge immediately.
        process.terminate()
        try:
            process.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.communicate()
        raise RuntimeError('Microphone capture timed out. Try pressing the mic button again.') from None
    if process.returncode:
        msg = error.strip() or f'Apple Speech exited with code {process.returncode}'
        raise RuntimeError(msg)
    spoken = output.strip()
    if not spoken:
        raise RuntimeError('Nothing was recognized; try again.')
    return spoken


def _spoken_words(text):
    """Tell the synthesizer to say Jarvis as a word, not an acronym."""
    import re
    words = str(text or '')
    words = re.sub(r'(?i)\bJ\s*\.\s*A\s*\.\s*R\s*\.\s*V\s*\.\s*I\s*\.\s*S\b', 'Jarvis', words)
    words = re.sub(r'(?i)\bJARVIS\b', 'Jarvis', words)
    return words.strip()


def _selected_speed_mode():
    """FAST native speech is instant to start; NATURAL loads neural Kokoro."""
    import os
    mode_path = Path(__file__).resolve().parent / 'voice_speed_mode.txt'
    override = os.environ.get('JARVIS_VOICE_MODE', '').strip().lower()
    if override in {'fast', 'natural'}:
        return override
    try:
        value=mode_path.read_text(encoding='utf-8').strip().lower()
        if value in {'fast','natural'}:
            return value
    except OSError:
        pass
    return 'fast'


def say(text, enabled=True):
    """Use recorded exact phrases first; fast native TTS by default.

    Nothing here changes microphones, permissions, models, or conversational
    content. Explicit neural mode remains available for voice quality.
    """
    if not enabled or sys.platform != 'darwin' or not text:
        return None
    from recorded_jarvis_voice import play_if_recorded
    words = _spoken_words(text)
    try:
        played=play_if_recorded(words)
        if played is not None:
            return played
    except (OSError, ImportError, ValueError):
        pass

    if _selected_speed_mode() == 'natural':
        from natural_voice_bridge import say as natural_voice_say
        return natural_voice_say(words, enabled=True)

    # Fast mode trades neural timbre for near-instant local speech startup.
    # Apple voice can be changed through existing FRIDAY voice preference.
    try:
        from gaurav_mac_features import read_voice
        voice = 'Samantha' if read_voice() == 'friday' else 'Daniel'
    except Exception:
        voice = 'Daniel'
    return subprocess.Popen(['/usr/bin/say', '-v', voice, '-r', '205', words[:900]],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def spoken_summary(result):
    return {
        'complete': 'Task completed. Please review the result.',
        'already_ready': 'The required applications are already running.',
        'refused': 'That request is not supported or permitted.',
        'cancelled': 'The action was cancelled.',
        'stopped': 'The task stopped. Check the details on screen.',
        'notes': 'Your saved notes are displayed.',
        'search': 'Matching notes are displayed.',
        'status': 'Task history is displayed.',
        'preview': 'Your action plan is ready for review.',
        'help': 'The help information is displayed.',
    }.get(result, 'Please review the response on screen.')
