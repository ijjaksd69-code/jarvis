"""Checksum-guarded, reversible updates to two microphone source files only."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,tempfile
HERE=Path(__file__).resolve().parent

def digest(data): return hashlib.sha256(data).hexdigest()

def atomic_write(path,data):
    fd,name=tempfile.mkstemp(prefix='.jarvis-repair-',dir=path.parent)
    staged=Path(name)
    try:
        with os.fdopen(fd,'wb') as out: out.write(data)
        shutil.copystat(path,staged)
        staged.replace(path)
    finally: staged.unlink(missing_ok=True)

def apply(root,rollback=False,check_only=False):
    rows=json.loads((HERE/'repair_manifest.json').read_text())
    pending=[]
    for name,hashes in rows.items():
        target=root/name; backup=root/(name+'.before_codex_recovery')
        if target.is_symlink() or backup.is_symlink(): raise RuntimeError('Refusing symlink: '+name)
        original=target.read_bytes(); current=digest(original)
        wanted=hashes['original' if rollback else 'patched']
        if current not in hashes.values(): raise RuntimeError('Unreviewed installed version: '+name)
        if backup.exists() and digest(backup.read_bytes())!=hashes['original']:
            raise RuntimeError('Unrelated backup exists: '+backup.name)
        if current==wanted: continue
        payload=(backup if rollback else HERE/name).read_bytes()
        if digest(payload)!=wanted: raise RuntimeError('Repair/backup checksum failed: '+name)
        compile(payload,name,'exec')
        pending.append((target,backup,original,payload))
    if check_only: return len(pending)
    # Complete all backup operations before modifying any source file.
    for target,backup,original,payload in pending:
        if not rollback and not backup.exists():
            with backup.open('xb') as out: out.write(original)
            shutil.copystat(target,backup)
    written=[]
    try:
        for target,backup,original,payload in pending:
            atomic_write(target,payload); written.append((target,original))
    except Exception:
        for target,original in reversed(written): atomic_write(target,original)
        raise
    return len(pending)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rollback',action='store_true'); parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    count=apply(Path.home()/'Library/Application Support/JARVIS Always On',args.rollback,args.check)
    print(('Validated' if args.check else 'Updated'),count,'source files. Models, memory and settings unchanged.')
