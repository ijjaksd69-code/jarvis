# Use this on the Mac where JARVIS is already installed

1. Extract this entire ZIP into one folder.
2. Open `VERIFY_AND_REPAIR.command` (right-click → Open if needed). Alternatively, open Terminal, type `bash `, drag that file into Terminal, and press Enter.
3. Follow the prompts: say “Hey Jarvis,” listen to both voice samples, then check the live hologram, an ordinary command, sleep, and wake again.
4. The result is saved as `JARVIS_VERIFICATION_RESULT.json` on your Desktop. Share that report if any check fails; it does not contain conversations or credentials.

The launcher validates the existing Python runtime and models, stops the listener, backs up and patches only voice_bridge.py and voice_input.py, tests permissions/wake/voice, then attempts to restart the existing service. It preserves your models, memory, recordings, voice selection, hologram and command policies. Unknown installed source versions are refused, not overwritten. The listener startup script now handles Python's -u option correctly.

This is an incremental repair package, not a replacement AI or a fresh-Mac installer. Keep your existing installation. Missing Python/voice runtimes or Mac permission problems will be reported, not concealed. Audio latency and audible output are confirmed only by the checks on your Mac.

Rollback: pause your installed JARVIS service, run `python3 apply_repairs.py --rollback` from this folder, then run `bash START_JARVIS_LISTENER.command`. Backups are retained beside the installed files with the suffix `.before_codex_recovery`.

Cloud validation: 21 repair/verifier tests, four existing wake tests, and three current-hologram tests pass. Three active models and eight archived checkpoints load; the active models also pass CPU inference smoke checks with unchanged weights. Historical tests still contain superseded expectations; this is not a claim that the entire historical suite passes. Native Mac speech, physical speakers, and real response timing cannot be verified from Linux.
